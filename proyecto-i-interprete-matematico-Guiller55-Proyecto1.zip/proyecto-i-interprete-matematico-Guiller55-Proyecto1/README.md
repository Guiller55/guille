[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=14263439&assignment_repo_type=AssignmentRepo)
# Proyecto I. Intérprete matemático
**Estructuras de Datos**

La entrega se realiza en este repositorio. 
* Recuerde hacer ```ant clean``` antes de los commits; no queremos archivos innecesarios.
* Está prohibido publicar las soluciones en reposiorios públicos.
